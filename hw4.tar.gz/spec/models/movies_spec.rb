require 'spec_helper'

describe Movie do

  describe 'search for movies wih same director' do

    # it 'should return movies with same director' do
    #     pending
    # end

  end
  
end